#!/ats/bin/perl
use warnings;

our $path              = $ARGV[0];
our $ip                = $ARGV[1];
our $called_port       = $ARGV[2];
our $calling_port      = $ARGV[3];

my $USAGE =<<USAGE;

 Usage:
                FORMAT : perl script_tick.pl <script path> <ServerIP> <called_port> <calling_port> 

                Example : perl script.pl /home/ranayak/14_1/test/test 10.54.81.77 5441 5446

                Note : ALL  are mandatory arguments,if not defined Script will exit with error
                <path>                  :Customer is 4 character String ex-RBBN for Ribbon
                <IP>                    :ServerType is 3 Character String , for ex C15, Q10
                <called_port>           :Customer Site is 4 Character String ,ex-for South Central , plano Texas it will be SCTX
                <calling_port>          :Region is 4 Character string , basically Aws Region ex -USE1,USW2


USAGE

if( $ARGV[0] eq '-h' || $ARGV[0] eq '-help')
{
 print "$USAGE\n";
    exit 0;
}

if (not defined $path ){
die "ServerType is Missing\n";
}
if (not defined $ip ){
die "ServerType is Missing\n";
}
if (not defined $called_port ){
die "ServerType is Missing\n";
}
if (not defined $calling_port ){
die "ServerType is Missing\n";
}



#my $register = 1;
my $register_main = `sipp -sf $path/uas_register.xml -i $ip -m 1 -inf $path/register.csv -p $called_port -trace_msg -bg`;
my $register_client = `sipp -sf $path/uac_register.xml $ip:$called_port -i $ip -m 1 -inf $path/register.csv -p $calling_port -trace_msg`;

print $?;

if ( $?  == 0)
{
	print ("\nRegistration of caller succesful\n");

}
else
{
	print ("\nRegistration of Caller failed\n");
		exit;
}

my $register_main1 = `sipp -sf $path/uas_register_2.xml -i $ip -m 1 -inf $path/register_2.csv -p $called_port -trace_msg -bg`;
my $register_server = `sipp -sf $path/uac_register_2.xml $ip:$called_port -i $ip -m 1 -inf $path/register_2.csv -p $calling_port -trace_msg`;

print $?;

if ( $? == 0)
{
        print ("\nRegistration of callee succesful\n");

}
else
{
        print ("\nRegistration of Callee failed\n");
        exit;
}

my $remove_message = `rm -rf *messages.log`;
my $remove_msg_log = `rm -rf *screen.log`;
my $server = `sipp -sf $path/uas.xml -i $ip -m 1 -p $called_port -trace_msg -bg`;
my $clinet = `sipp -sf $path/uac.xml $ip:$called_port -i $ip -m 1 -p $calling_port -trace_msg -trace_screen`;

print $?;


if ( $? == 0)
{
        print ("\nCall is succesful\n");

}
else
{
        print ("\nCall failure\n");
        exit;
}


my $invite_msg = `sed \"s/[^0-9][- ]//g\" *messages.log | sed 1q`;


print "The time at which invite was received at callee $invite_msg\n";

my $testt = `grep -i -B 3 \"200 OK\" uac_*_messages.log | tee t2.txt`;

my $msg_200ok = `sed \"s/[^0-9][- ]//g\" t2.txt | sed 1q`;

print "Time at which caller received 200 OK: $msg_200ok\n";

my $msg_bye_mesage = `grep -i -B 3 \"BYE\" uac_*_messages.log | tee t3.txt`;

my $msg_bye = `sed \"s/[^0-9][- ]//g\" t3.txt | sed 1q`;

print "Time at which BYE was sent by caller: $msg_bye\n";

my $screen_test = `grep -o -P '(?<=$calling_port).*(?=s)' *screen.log | tee t4.txt`;

my $screen_msg = `sed \"s/ //g\" t4.txt`;

print "Total call duration in seconds : $screen_msg";



